export default {
  todos: [
      {
          "imgUrl": "https://placehold.co/300x200",
          "title": "Card 1",
          "content": "Texto de la card 1"
      },
      {
          "imgUrl": "https://placehold.co/300x200",
          "title": "Card 2",
          "content": "Texto de la card 2"
      },
      {
          "imgUrl": "https://placehold.co/300x200",
          "title": "Card 3",
          "content": "Texto de la card 3"
      },
      {
          "imgUrl": "https://placehold.co/300x200",
          "title": "Card 4",
          "content": "Texto de la card 4"
      },
      {
          "imgUrl": "https://placehold.co/300x200",
          "title": "Card 5",
          "content": "Texto de la card 5"
      },
  ]
}
